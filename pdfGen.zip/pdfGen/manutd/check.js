const path = require('path');
const fs = require('fs');
const { text, image, barcodes } = require('@pdfme/schemas');
const { generate } = require('@pdfme/generator');
const readline = require('readline');
async function editPDFWithData(id, data) {
  try {
    let templatePdfPath = 'basePdf.pdf';
    const csvFiles = listCsvFiles();
    const selectedFile = await promptUserToChooseFile(csvFiles);
    const dataProcess = processCsvFile(selectedFile);
    for (const data of dataProcess) {
      const timestamp = Date.now();
      let outputPdfPath = `${process.cwd()}/data/unitedPdfGenerator/ticket_${data.supporterId}_${timestamp}.pdf`;
      const font = {
        simplified_arabic_bold: {
          data: fs.readFileSync(`${process.cwd()}/pdfGen/manutd/fonts/akhbar_bold.ttf`),
          fallback: true,
        },
      };
      outputPdfPath = `${outputPdfPath}ticket${id}.pdf`;
      const templatePdfBytes = fs.readFileSync(`${process.cwd()}/pdfGen/manutd/${templatePdfPath}`);
      const template = {
        schemas: JSON.parse(fs.readFileSync(`${process.cwd()}/pdfGen/manutd/schema.json`).toString()),
        basePdf: 'data:application/pdf;base64,' + Buffer.from(templatePdfBytes).toString('base64'),
      };
      const res = await fetch(`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${data.qr}`);
      const qrBuffer = await res.arrayBuffer();
      const plugins = {
        text,
        image,
        qrcode: barcodes.qrcode,
      };
      const inputs = [
        {
          game: data.game,
          date: `${data.date}, ${data.time}`,
          supporter_id: 'Supporter ID: ' + data.supporterId,
          priceClass: 'Price Class: ' + data.priceClass,
          block: data.block,
          row: data.row,
          seat: data.seat,
          entrance: data.entrance,
          qr: 'data:image/png;base64,' + Buffer.from(qrBuffer).toString('base64'),
        },
      ];
      const pdf = await generate({
        template,
        plugins,
        inputs,
        options: {
          font,
        },
      });
      fs.writeFileSync(outputPdfPath, pdf);
      console.log('Generated PDF Succesfully');
    }
  } catch (error) {
    console.log(error);
  }
}
module.exports = editPDFWithData;
function listCsvFiles() {
  const directoryPath = path.join(process.cwd(), 'data/unitedPdfGenerator');
  return fs.readdirSync(directoryPath).filter((file) => path.extname(file).toLowerCase() === '.csv');
}
function processCsvFile(fileName) {
  const filePath = path.join(process.cwd(), 'data/unitedPdfGenerator', fileName);
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n').filter((line) => line.trim() !== '');
  lines.shift();
  return lines.map((line) => {
    const [game, date, time, block, row, seat, entrance, supporterId, priceClass, qr] = line
      .replace(/\r$/, '')
      .split(',')
      .map((item) => item.trim());
    return {
      game: game,
      date: date,
      time: time,
      block: block,
      row: row,
      seat: seat,
      supporterId: supporterId,
      entrance: entrance,
      priceClass: priceClass,
      qr: qr,
    };
  });
}
function promptUserToChooseFile(files) {
  return new Promise((resolve) => {
    console.log('Available CSV files:');
    files.forEach((file, index) => {
      console.log(`${index + 1}: ${file}`);
    });
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    rl.question('Enter the number of the file you want to process: ', (answer) => {
      const fileIndex = parseInt(answer, 10) - 1;
      if (fileIndex >= 0 && fileIndex < files.length) {
        resolve(files[fileIndex]);
        rl.close();
      } else {
        console.log('Invalid selection. Please try again.');
        rl.close();
        resolve(promptUserToChooseFile(files));
      }
    });
  });
}
